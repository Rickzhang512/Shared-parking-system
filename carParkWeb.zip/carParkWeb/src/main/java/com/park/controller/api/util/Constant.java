package com.park.controller.api.util;

public class Constant {
    public static final String APPID = "wx372519058fc9ae7c";
    public static final String SECRET = "d2fcdcbffd1b7441a3a3dd013eab6a3a";
}
