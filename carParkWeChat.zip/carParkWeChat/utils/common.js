const AV = require('av-weapp-min.js');
const util = require('util.js');
module.exports = {
  AV,
  util
}